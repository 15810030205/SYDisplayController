//
//  MainViewController.m
//  SYDisPlayControllerDemo
//
//  Created by 郝松岩 on 2017/8/9.
//  Copyright © 2017年 haosongyan. All rights reserved.
//

#import "MainViewController.h"
#import "OneViewController.h"
#import "TwoViewController.h"
#import "ThreeViewController.h"


@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpAllChildrenController];
    [self setUpAllProperty:^(UIColor *__autoreleasing *titleBackgroundColor, UIColor *__autoreleasing *titleColor_Nor, UIColor *__autoreleasing *titleColor_Sel, UIFont *__autoreleasing *titleFontSize, CGFloat *titleBackHeight, CGFloat *titleWidth, UIColor *__autoreleasing *titleLineCor, UIColor *__autoreleasing *titleSelectCor) {
        *titleBackgroundColor = [UIColor whiteColor];
        *titleColor_Nor = [UIColor grayColor];
        *titleColor_Sel = [UIColor blackColor];
        *titleFontSize = [UIFont systemFontOfSize:13];
        *titleBackHeight = 40;
        *titleLineCor = [UIColor cyanColor];
        *titleSelectCor = [UIColor blackColor];
    }];
    
    
}
- (void)setUpAllChildrenController
{
    OneViewController *controllerone = [OneViewController new];
    controllerone.title = @"测试1";
    [self addChildViewController:controllerone];
    
    TwoViewController *controllertwo = [TwoViewController new];
    controllertwo.title = @"测试2";
    [self addChildViewController:controllertwo];
    
    ThreeViewController *controllerthre = [ThreeViewController new];
    controllerthre.title = @"测试3";
    [self addChildViewController:controllerthre];

}

@end
