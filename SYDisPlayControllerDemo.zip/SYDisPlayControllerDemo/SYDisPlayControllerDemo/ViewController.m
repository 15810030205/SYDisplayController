//
//  ViewController.m
//  SYDisPlayControllerDemo
//
//  Created by 郝松岩 on 2017/8/8.
//  Copyright © 2017年 haosongyan. All rights reserved.
//

#import "ViewController.h"
#import "MainViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)PushNewView:(id)sender {
    
    MainViewController *controller = [MainViewController new];
    [self.navigationController pushViewController:controller animated:YES];
    
    
}
- (IBAction)presentNewView:(id)sender {


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
