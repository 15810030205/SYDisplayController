//
//  AppDelegate.h
//  SYDisPlayControllerDemo
//
//  Created by 郝松岩 on 2017/8/8.
//  Copyright © 2017年 haosongyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

