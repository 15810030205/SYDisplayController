//  布局类 如果有其它要求 可以在本类中直接进行更改
//  SYLayout.m
//  SYDisPlayControllerDemo
//
//  Created by hsy on 2017/8/8.
//  Copyright © 2017年 hsy. All rights reserved.
//


#define ControllerSize_Width   self.collectionView.bounds.size.width
#define ControllerSize_Height  self.collectionView.bounds.size.height

#define Min_InterSpace  0
#define Min_LineSpace   0

#import "SYLayout.h"

@implementation SYLayout

-(void)prepareLayout
{
    [super prepareLayout];
    self.itemSize = CGSizeMake(ControllerSize_Width, ControllerSize_Height);
    //设置相邻Item距离
    self.minimumInteritemSpacing = Min_InterSpace;
    //设置水平空间距离
    self.minimumLineSpacing = Min_LineSpace;
    //设置水平滚动
    self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
}
@end
