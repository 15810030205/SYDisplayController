//
//  SYLayout.h
//  SYDisPlayControllerDemo
//
//  Created by hsy on 2017/8/8.
//  Copyright © 2017年 hsy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYLayout : UICollectionViewFlowLayout

@end
