//
//  SYTitleLabel.m
//  SYDisPlayControllerDemo
//
//  Created by 郝松岩 on 2017/8/9.
//  Copyright © 2017年 haosongyan. All rights reserved.
//

#import "SYTitleLabel.h"

@implementation SYTitleLabel
- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    
    [_color set];
    
    rect.size.width = rect.size.width * _progress;
    
    UIRectFillUsingBlendMode(rect, kCGBlendModeSourceIn);
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.userInteractionEnabled = YES;
        
        self.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}


- (void)setProgress:(CGFloat)progress
{
    _progress = progress;
    
    [self setNeedsDisplay];
}

@end
