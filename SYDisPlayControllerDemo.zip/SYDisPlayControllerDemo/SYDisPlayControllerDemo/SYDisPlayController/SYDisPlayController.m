//
//  SYDisPlayController.m
//  SYDisPlayControllerDemo
//
//  Created by hsy on 2017/8/8.
//  Copyright © 2017年 hsy. All rights reserved.
//

#import "SYDisPlayController.h"
#import "SYLayout.h"
#import "SYTitleLabel.h"

#define SYScreen_Width         [UIScreen mainScreen].bounds.size.width
#define SYScreen_Height        [UIScreen mainScreen].bounds.size.height

static NSString *collectionid = @"collectionid";
static CGFloat  marginSpace = 20;//标题间距
static CGFloat  SYNavHeight = 0;//导航高度

@interface SYDisPlayController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong)UICollectionView *collectionview;//承载Controller
@property (nonatomic,strong)UIView *contentAllView;//承载标题与内容View
@property (nonatomic,strong)UIScrollView *titleScrollView;//承载标题 该View增加在ContentAllView上

@property (nonatomic,strong)NSMutableArray *titleArray;//标题数组
@property (nonatomic,strong)NSMutableArray *titleWidthArray;//标题宽度数组

@property (nonatomic,strong)UIView *underLine;//标题底部横线
@property (nonatomic,strong)UIView *converView;//标题遮盖
@property (nonatomic,assign)CGFloat lastMoveX;//最新移动后的偏移
@property (nonatomic, assign) NSInteger selIndex;
@property (nonatomic, assign) BOOL isInitial;//是否已经初始化过
@property (nonatomic, strong) UIView *titleBottomLine;//标题底部横线

@end

@implementation SYDisPlayController

#pragma mark -- 设置方法
- (void)setUpAllProperty:(void(^)(UIColor **titleBackgroundColor,UIColor **titleColor_Nor,UIColor **titleColor_Sel,UIFont **titleFontSize,CGFloat *titleBackHeight,CGFloat *titleWidth,UIColor **titleLineCor,UIColor **titleSelectCor))allPropertyBlock
{
    UIColor *titleBackgroundColor;
    UIColor *titleColor_Nor;
    UIColor *titleColor_Sel;
    UIFont  *titleFontSize ;
    UIColor *titleLineCor;
    UIColor *titleSelectCor;
    
    if (allPropertyBlock) {
        allPropertyBlock(&titleBackgroundColor,&titleColor_Nor,&titleColor_Sel,&titleFontSize,&_titleBackHeight,&_titleWidth,&titleLineCor,&titleSelectCor);
        _titleBackgroundColor = titleBackgroundColor;
        _titleColor_Nor = titleColor_Nor;
        _titleColor_Sel = titleColor_Sel;
        _titleFontSize = titleFontSize;
        _titleLineCor = titleLineCor;
        _titleSelectCor = titleSelectCor;
    }
}


- (void)setUpContentViewFrame:(void(^)(UIView *contentView))contentBlock
{
    if (contentBlock) {
        contentBlock(self.contentAllView);
    }

}
#pragma mark -- 生命周期

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CGFloat navHeight = self.navigationController ? SYNavHeight :[UIApplication sharedApplication].statusBarFrame.size.height;
    CGFloat contentWidth = SYScreen_Width;
    CGFloat contentHeight = SYScreen_Height - navHeight;
    //整个内容（带标题）尺寸
    if (self.contentAllView.frame.size.height == 0) {
        self.contentAllView.frame = CGRectMake(0, navHeight, contentWidth, contentHeight);
        
    }
    //标题尺寸
    CGFloat titleHeight = _titleBackHeight ;
    CGFloat titleY = navHeight;
    self.titleScrollView.frame = CGRectMake(0, titleY, contentWidth, titleHeight);
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.translucent = NO;
    [self.navigationController setNavigationBarHidden: NO
                                             animated: NO];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (!_isInitial) {
        _isInitial = YES;
      
    //注册collectionViewCell
        [self.collectionview registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:collectionid];
        //这里背景颜色写死了 后期需要可以更改
        self.collectionview.backgroundColor = [UIColor whiteColor];
        
        if (self.childViewControllers.count == 0) {
          
            NSException *children = [[NSException alloc]initWithName:@"不好意思，让你崩溃" reason:@"因为你不按照规矩来，所以让你崩溃" userInfo:nil];
            
            NSString * errorinfo = [NSString stringWithFormat:@"%@ %d %s",[self class],__LINE__,__PRETTY_FUNCTION__];
            
            NSLog(@"需要加入子控制器，否则崩溃 %@",errorinfo);
            
            @throw children;
            
        }
        
        [self setUpTitleWidth];
        [self setUpTitle];
        
    }
    
    
}
#pragma mark -- 设置标题宽度
- (void)setUpTitleWidth
{
    NSInteger titleCount = self.childViewControllers.count;
    NSArray *titleArray = [self.childViewControllers valueForKey:@"title"];
    
//    _titleArray = [NSMutableArray arrayWithArray:titleArray];
    
    if (titleArray.count == 0 || titleCount != titleArray.count) {
        NSException *children = [[NSException alloc]initWithName:@"不好意思，让你崩溃" reason:@"因为你不按照规矩来，所以让你崩溃" userInfo:nil];
        
        NSString * errorinfo = [NSString stringWithFormat:@"%@ %d %s",[self class],__LINE__,__PRETTY_FUNCTION__];
        
        NSLog(@"不能少title 需要在设置childrenController的时候就要增加title %@",errorinfo);
        
        @throw children;

    }
    
    CGFloat totalTitleWidth = 0;
    
    for (NSString *titleString in titleArray) {
        
        CGRect titleWidthRect = [titleString boundingRectWithSize:CGSizeMake(MAXFLOAT, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.titleFontSize} context:nil];
        
        CGFloat titleWidth = 0 ;
        
        if (_titleWidth) {
            titleWidth = _titleWidth;
        }else{
            titleWidth = titleWidthRect.size.width;
        }
        [self.titleWidthArray addObject:@(titleWidth)];
        //每次加上这次宽度
        totalTitleWidth += titleWidth;
        
        if (totalTitleWidth > SYScreen_Width) {
            self.titleScrollView.contentInset = UIEdgeInsetsMake(0, 0, 0, marginSpace);
            return;
        }
        CGFloat titleMargin = (SYScreen_Width - totalTitleWidth) / (titleCount + 1);
        
        marginSpace = titleMargin < marginSpace? marginSpace: titleMargin;
        
        self.titleScrollView.contentInset = UIEdgeInsetsMake(0, 0, 0, marginSpace);

    }
    
}
#pragma mark -- 设置标题
-(void)setUpTitle
{
    NSUInteger count = self.childViewControllers.count;
    
    CGFloat labelW = 0;
    CGFloat labelH = self.titleBackHeight;
    CGFloat labelX = 0;
    CGFloat labelY = 0;
    
    for (int i = 0; i < count; i++) {
        
        UIViewController *vc = self.childViewControllers[i];
        
        UILabel *label = [[SYTitleLabel alloc] init];
        
        label.tag = i;
        
        label.textColor = self.titleColor_Nor;
        
        label.font = self.titleFontSize;
        
        label.text = vc.title;
        
        labelW = [self.titleWidthArray[i] floatValue];
        
        UILabel *lastLabel = [self.titleArray lastObject];
        
        labelX = marginSpace + CGRectGetMaxX(lastLabel.frame);
        
        label.frame = CGRectMake(labelX, labelY, labelW, labelH);
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(titleClick:)];
        [label addGestureRecognizer:tap];
        
        [self.titleArray addObject:label];
        
        [_titleScrollView addSubview:label];
        
        if (i == _isSelectIndex) {
            [self titleClick:tap];
        }
    }
    
    UILabel *lastLabel = self.titleArray.lastObject;
    _titleScrollView.contentSize = CGSizeMake(CGRectGetMaxX(lastLabel.frame), 0);
    _titleScrollView.showsHorizontalScrollIndicator = NO;
    _collectionview.contentSize = CGSizeMake(count * SYScreen_Width, 0);
    
    
}
// 标题按钮点击
- (void)titleClick:(UITapGestureRecognizer *)tap
{
    
    // 获取对应标题label
    UILabel *label = (UILabel *)tap.view;
    
    // 获取当前角标
    NSInteger i = label.tag;
    
    // 选中label
    [self selectLabel:label];
    
    // 内容滚动视图滚动到对应位置
    CGFloat offsetX = i * SYScreen_Width;
    
    self.collectionview.contentOffset = CGPointMake(offsetX, 0);
    
    // 记录上一次偏移量,因为点击的时候不会调用scrollView代理记录，因此需要主动记录
    _lastMoveX = offsetX;
    
    // 添加控制器
    UIViewController *vc = self.childViewControllers[i];
    
    // 判断控制器的view有没有加载，没有就加载，加载完在发送通知
    if (vc.view) {
        // 发出通知点击标题通知
        [[NSNotificationCenter defaultCenter] postNotificationName:@"SYDisplayControllerSlectIndex"  object:vc];
        
        // 发出重复点击标题通知
        if (_selIndex == i) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"SYDisplayControllerRepeatSlectIndex" object:vc];
        }
    }
    
    _selIndex = i;
    
}

- (void)selectLabel:(UILabel *)label
{
    
    for (SYTitleLabel *titleLabel in self.titleArray) {
        
        if (label == titleLabel){
        
            titleLabel.textColor = self.titleColor_Sel;
        }else{
            titleLabel.color = self.titleColor_Nor;
            
            titleLabel.progress = 1;
        }
    }
    
    
    // 修改标题选中颜色
    label.textColor = self.titleColor_Sel;
    
    // 设置标题居中
    [self setLabelTitleCenter:label];
    
    // 设置下标的位置
    [self setUpUnderLine:label];
    
    
}
// 让选中的按钮居中显示
- (void)setLabelTitleCenter:(UILabel *)label
{
    
    // 设置标题滚动区域的偏移量
    CGFloat offsetX = label.center.x - SYScreen_Width * 0.5;
    
    if (offsetX < 0) {
        offsetX = 0;
    }
    
    // 计算下最大的标题视图滚动区域
    CGFloat maxOffsetX = self.titleScrollView.contentSize.width - SYScreen_Width + marginSpace;
    
    if (maxOffsetX < 0) {
        maxOffsetX = 0;
    }
    
    if (offsetX > maxOffsetX) {
        offsetX = maxOffsetX;
    }
    
    // 滚动区域
    [self.titleScrollView setContentOffset:CGPointMake(offsetX, 0) animated:YES];
    
}
// 设置下标的位置
- (void)setUpUnderLine:(UILabel *)label
{
    
}
#pragma mark -- LazyLoad converView
- (UIView *)converView
{
    if (_converView == nil) {
        _converView = [UIView new];
        
        _converView.backgroundColor = [UIColor lightGrayColor];
        
        
        [self.titleScrollView insertSubview:_converView atIndex:0];
        
    }
    return _converView;
}


#pragma mark -- LazyLoad underLine
- (UIView *)underLine
{
    if (_underLine) {
        _underLine = [UIView new];
        _underLine.backgroundColor = _titleSelectCor;
        
        [_titleScrollView addSubview:_underLine];
    }
    
    return _underLine;
}


#pragma mark -- LazyLoad titleWidthArray
- (NSMutableArray *)titleWidthArray
{
    if (!_titleWidthArray) {
        _titleWidthArray = [NSMutableArray new];
    }
    return _titleWidthArray;
}

#pragma mark -- LazyLoad titleArray
- (NSMutableArray *)titleArray
{
    if (!_titleArray) {
        _titleArray = [NSMutableArray new];
    }
    return _titleArray;
}


#pragma mark -- LazyLoad titleBottomLine
- (UIView *)titleBottomLine
{
    if (!_titleBottomLine) {
        _titleBottomLine = [UIView new];
        _titleBottomLine.backgroundColor = _titleLineCor?_titleLineCor:[UIColor clearColor];
        [_contentAllView addSubview:_titleBottomLine];
    }
    
    return _titleBottomLine;
}

#pragma mark -- LazyLoad titleScrollView
- (UIScrollView *)titleScrollView
{
    if (!_titleScrollView) {
        _titleScrollView = [UIScrollView new];
        _titleScrollView.backgroundColor = _titleBackgroundColor?_titleBackgroundColor:[UIColor whiteColor];
        [_contentAllView addSubview:_titleScrollView];
    }
    return _titleScrollView;
}

#pragma mark -- LazyLoad ContrentAllView
- (UIView *)contentAllView
{
    if (!_contentAllView) {
        _contentAllView = [UIView new];
        [self.view addSubview:_contentAllView];
    }
    return _contentAllView;
}
#pragma mark -- LazyLoad CollectionView
- (UICollectionView *)collectionview
{
    if (!_collectionview) {
        SYLayout *layout = [SYLayout new];
        
        UICollectionView *contentScrollView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _collectionview = contentScrollView;
        _collectionview.frame = CGRectMake(0, 0, SYScreen_Width, SYScreen_Height);//这里先生成 后面修改
        _collectionview.collectionViewLayout = layout;
        _collectionview.delegate = self;
        _collectionview.dataSource = self;
        _collectionview.scrollsToTop = NO;
        _collectionview.pagingEnabled = YES;
        _collectionview.showsHorizontalScrollIndicator = NO;
        
        [self.contentAllView insertSubview:_collectionview belowSubview:self.titleScrollView];

    }
    return _collectionview;
}



#pragma mark -- CollectionViewDelegate

-(NSInteger )collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.childViewControllers.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectionid forIndexPath:indexPath];
    [cell.contentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    UIViewController *controller = self.childViewControllers[indexPath.row];
    controller.view.frame = CGRectMake(0, 0, _collectionview.bounds.size.width, _collectionview.bounds.size.height);
    
    [cell.contentView addSubview:controller.view];
    
    return cell;
}




@end
