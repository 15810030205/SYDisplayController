//
//  SYDisPlayController.h
//  SYDisPlayControllerDemo
//
//  Created by hsy on 2017/8/8.
//  Copyright © 2017年 hsy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYDisPlayController : UIViewController


/******************标题相关*******************/

/**
 标题背景颜色
 */
@property (nonatomic,strong)UIColor *titleBackgroundColor;

/**
 标题字体颜色——正常
 */
@property (nonatomic,strong)UIColor *titleColor_Nor;

/**
 标题字体颜色——选中
 */
@property (nonatomic,strong)UIColor *titleColor_Sel;

/**
 标题字体大小
 */
@property (nonatomic,assign)UIFont *titleFontSize;

/**
 标题字体背景高度（整个标题滚动区域高度）
 */
@property (nonatomic,assign)CGFloat titleBackHeight;


/**
 标题中每个title的宽度 
 */
@property (nonatomic,assign)CGFloat titleWidth;

/**
 标题底部横线颜色
 */
@property (nonatomic,strong)UIColor *titleLineCor;


/**
 标题底部选中横线颜色
 */
@property (nonatomic,strong)UIColor *titleSelectCor;

/**
 是否显示标题背景底部线
 */
@property (nonatomic,assign)BOOL isShowTitleBottomLine;

/******************标题相关*******************/

/**
 选中
 */
@property (nonatomic,assign)NSInteger isSelectIndex;


- (void)setUpAllProperty:(void(^)(UIColor **titleBackgroundColor,UIColor **titleColor_Nor,UIColor **titleColor_Sel,UIFont **titleFontSize,CGFloat *titleBackHeight,CGFloat *titleWidth,UIColor **titleLineCor,UIColor **titleSelectCor))allPropertyBlock;

- (void)setUpContentViewFrame:(void(^)(UIView *contentView))contentBlock;

@end
