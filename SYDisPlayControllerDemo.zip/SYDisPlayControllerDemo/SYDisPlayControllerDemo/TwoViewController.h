//
//  TwoViewController.h
//  SYDisPlayControllerDemo
//
//  Created by 郝松岩 on 2017/8/9.
//  Copyright © 2017年 haosongyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TwoViewController : UIViewController

@end
